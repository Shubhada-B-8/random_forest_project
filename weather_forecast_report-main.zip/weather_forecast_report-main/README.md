# weather_forecast_in_real_time
weather forecast in real time report for code conflux 2025 by team Dev001 

here we enter the name of location of which we want to know weather
![Screenshot 2025-02-02 214224](https://github.com/user-attachments/assets/b215f31d-5d6f-4234-a9cc-20f6573ad606)

After entering the location we will get the weather report of the place
IT WILL CONSIST OF :
1. TEMPERATURE
2. CURRENT WIND SPEED
3. HUMIDITY
4. IMAGE SHOWING THE WEATHER OF PLACE like it is sunny ,cloudy ,rainy,etc
   
![Screenshot 2025-02-02 214203](https://github.com/user-attachments/assets/ae72fb29-b994-4d16-936a-a2637a6bc971)
![Screenshot 2025-02-02 214354](https://github.com/user-attachments/assets/8e590229-30da-46ad-8227-e4d8e340225e)
![Screenshot 2025-02-02 214302](https://github.com/user-attachments/assets/28a3c09e-bc75-4bff-b718-59817ff4bf9d)
![Screenshot 2025-02-02 214337](https://github.com/user-attachments/assets/39ec5bc8-ae29-482f-9bb0-e1e7b1b1d220)
